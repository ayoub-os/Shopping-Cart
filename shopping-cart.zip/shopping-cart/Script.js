// Remove Items From Product Items
var x = document.querySelectorAll('.cancel');
for (let i = 0; i < x.length; i++) {
    x[i].addEventListener('click', removeItem)
    function removeItem(e){
        if(e.target.classList.contains('cancel')){
            x[i].parentNode.remove()
        }
    }
}
// Product Item Total
var price = document.querySelectorAll('.price');
var qty = document.querySelectorAll('#qty');
var cost = [];
for (let j = 0; j < price.length; j++) {
    cost[j] = parseFloat(price[j].innerHTML);
}
for (let a = 0; a < qty.length; a++) {
    qty[a].addEventListener('change' , sum)
    function sum(e){
        price[a].innerHTML = qty[a].value * cost[a];
    }
}
// All Products Total
var subTotal = document.querySelector('.sub-total')
subTotal.innerHTML = '₤' + 81;
for (let b = 0; b < price.length; b++) {
    qty[b].addEventListener('change' , totalFunction)
    function totalFunction(){
        var total = 0;
        for (let c = 0; c < price.length; c++) {
            total += parseFloat(price[c].innerHTML);
        }
        subTotal.innerHTML = '₤' + total;
    }
}